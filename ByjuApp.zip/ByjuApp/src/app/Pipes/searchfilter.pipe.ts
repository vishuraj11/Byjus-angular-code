import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'searchfilter'
})
export class SearchfilterPipe implements PipeTransform {

  transform(value: any, args?:any): any {
    console.log(value,args);
    if(!args)
    {
      return value;
    }
    return value.filter(items=>{
      return items.location.toLowerCase().startsWith(args.toLowerCase())==true
    })

   }

}
