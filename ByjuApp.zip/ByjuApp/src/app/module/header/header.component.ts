import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent  {

  isLoggedIn: boolean=false;
  key:string='username';
  constructor(private router: Router) { 
   if(sessionStorage.getItem(this.key)!=null||
    sessionStorage.getItem(this.key)!=undefined){
      this.isLoggedIn=true;
   }
 }

 navigateSidebarPage(){
   this.router.navigate(['login']);
 }

 navigateLoginPage(){
   sessionStorage.removeItem(this.key);
   sessionStorage.removeItem("sessionId");
   this.isLoggedIn=false;
   this.router.navigate(['login']);
 }

}
