import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/service/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  public isLoggedIn: boolean = false;
  key:string='username';

  public data:any=[]
  userloginForm: FormGroup;
  vdata:any;


//   userListCollection=[
//     {
//       username:"admin",
//       password:"admin"
//     }
// ];
  
constructor(private formBuilder: FormBuilder,private router: Router,private authService:AuthService) {
   
   }

  submitted: boolean;
  loginSuccess:boolean=false;
  loginfalure:boolean;
  showSuccessMessage: boolean;
  updateSuccessMassage: boolean;
  
  ngOnInit() {

    this.userloginForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
  });
  }

  get f() { return this.userloginForm.controls; }

  onSubmit() {
    this.submitted = true;
    if (this.userloginForm.invalid) {
        return;
    }else{
      var that = this;this
      if(that.userloginForm.value.username=="admin" && that.userloginForm.value.password=="admin"){
        sessionStorage.setItem(that.key,that.userloginForm.value.username);
        this.loginSuccess=true;
        
        setTimeout(()=>this.loginSuccess=false,2000)
            
        this.router.navigate(['/joblist']);
      }else{
        console.log("Error");
          this.loginfalure=true;
          setTimeout(()=>this.loginfalure=false,3000)
      }
      
        
    }
  }

}
