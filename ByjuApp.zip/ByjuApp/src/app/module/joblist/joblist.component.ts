import { Component, OnInit } from '@angular/core';
import { JobsService } from 'src/app/service/jobs.service';

@Component({
  selector: 'app-joblist',
  templateUrl: './joblist.component.html',
  styleUrls: ['./joblist.component.css']
})
export class JoblistComponent implements OnInit {
  config: any;
  public data:any=[]
  joblist: any=[];
  filtertext:any;
  constructor(private jobsService:JobsService) { 
    this.config = {
      itemsPerPage: 10,
      currentPage: 1
    };
  }

  ngOnInit() {
    this.jobsService.getUsers().subscribe(job=>{
      console.log(job.data);  
     this.joblist=job.data;
    })
 
  }

}
