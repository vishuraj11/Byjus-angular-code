import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './module/header/header.component';
import { LoginComponent } from './module/login/login.component';
import { AuthService } from './service/auth.service';
import { JobsService } from './service/jobs.service';
import { AuthGuardService } from './service/auth-guard.service';
import { HttpClientModule } from '@angular/common/http';
import {NgxPaginationModule} from 'ngx-pagination';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { StorageServiceModule} from 'angular-webstorage-service';
import { JoblistComponent } from './module/joblist/joblist.component';
import { SearchfilterPipe } from './Pipes/searchfilter.pipe';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    LoginComponent,
    JoblistComponent,
    SearchfilterPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule,
    NgxPaginationModule,
    StorageServiceModule

  ],
  providers: [AuthService,JobsService, AuthGuardService],
  bootstrap: [AppComponent]
})
export class AppModule { }
