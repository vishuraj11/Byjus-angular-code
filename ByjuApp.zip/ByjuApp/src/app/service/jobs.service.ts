import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class JobsService {

  url: string = "https://nut-case.s3.amazonaws.com/jobs.json";
  constructor(private http: HttpClient) { }

  getUsers() {
    return this.http.get<Job>(this.url);
  }
}

export class Job{
  constructor(public responseStatus:Object, public data:Object) {}
}