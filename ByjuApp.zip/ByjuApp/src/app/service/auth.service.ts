import { Injectable } from '@angular/core';
import { HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
 
  key:string='username';
  constructor() { }

  public isAuthenticated(): boolean {

    const token = sessionStorage.getItem(this.key);

    return !(token === null);
  }
}
